import React from 'react'

const parentref = React.forwardRef((props,ref)=>{
  
})

export default parentref